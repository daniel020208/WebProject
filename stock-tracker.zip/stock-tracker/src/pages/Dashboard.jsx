import React, { useState, useMemo, useEffect } from 'react';
import { Link } from 'react-router-dom';
import StockCard from '../components/StockCard';
import CryptoCard from '../components/CryptoCard';
import Button from '../components/Button';
import Input from '../components/Input';
import Label from '../components/Label';
import Select from '../components/Select';

const defaultStocks = [
  { id: 1, name: 'Microsoft', symbol: 'MSFT', price: 300, change: 1.2, volume: 1000000 }
];

const defaultCryptos = [
  { id: 1, name: 'Bitcoin', symbol: 'BTC', price: 45000, change: 2.5, volume: 500000 }
];

function Dashboard({ stocks = defaultStocks, cryptos = defaultCryptos, onDeleteStock, onDeleteCrypto }) {
  const [showStocks, setShowStocks] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState('name');
  const [sortOrder, setSortOrder] = useState('asc');
  const [userStocks, setUserStocks] = useState(stocks);
  const [userCryptos, setUserCryptos] = useState(cryptos);

  useEffect(() => {
    // Fetch stocks and cryptos data
    setUserStocks(stocks);
    setUserCryptos(cryptos);
  }, [stocks, cryptos]);

  const filteredAndSortedItems = useMemo(() => {
    const items = showStocks ? userStocks : userCryptos;
    return items
      .filter(item => item.name.toLowerCase().includes(searchQuery.toLowerCase()))
      .sort((a, b) => {
        const aValue = a[sortBy];
        const bValue = b[sortBy];
        if (aValue < bValue) return sortOrder === 'asc' ? -1 : 1;
        if (aValue > bValue) return sortOrder === 'asc' ? 1 : -1;
        return 0;
      });
  }, [showStocks, userStocks, userCryptos, searchQuery, sortBy, sortOrder]);

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <h1 className="text-4xl font-bold text-text-primary">Your {showStocks ? 'Stock' : 'Crypto'} Dashboard</h1>
        <Link to="/add-stock">
          <Button className="bg-accent hover:bg-accent-dark text-white font-bold py-2 px-4 rounded-lg transition duration-300 ease-in-out transform hover:scale-105">
            Add New {showStocks ? 'Stock' : 'Crypto'}
          </Button>
        </Link>
      </div>

      <div className="flex flex-col md:flex-row justify-between items-start md:items-center space-y-4 md:space-y-0 md:space-x-4">
        <div className="flex items-center space-x-2">
          <Label htmlFor="show-stocks" className="text-text-primary">Show:</Label>
          <Select
            id="show-stocks"
            value={showStocks ? "stocks" : "crypto"}
            onChange={(e) => setShowStocks(e.target.value === "stocks")}
          >
            <option value="stocks">Stocks</option>
            <option value="crypto">Cryptocurrencies</option>
          </Select>
        </div>

        <div className="flex-1 max-w-sm">
          <Input
            type="text"
            placeholder="Search by name or symbol"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full"
          />
        </div>

        <div className="flex items-center space-x-2">
          <Label htmlFor="sort-by" className="text-text-primary">Sort by:</Label>
          <Select
            id="sort-by"
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
          >
            <option value="name">Name</option>
            <option value="symbol">Symbol</option>
            <option value="price">Price</option>
            <option value="change">Change %</option>
            <option value="volume">Volume</option>
          </Select>
        </div>

        <div className="flex items-center space-x-2">
          <Label htmlFor="sort-order" className="text-text-primary">Order:</Label>
          <Select
            id="sort-order"
            value={sortOrder}
            onChange={(e) => setSortOrder(e.target.value)}
          >
            <option value="asc">Ascending</option>
            <option value="desc">Descending</option>
          </Select>
        </div>
      </div>

      <div className="grid gap-8 grid-cols-1">
        {filteredAndSortedItems.map((item) => (
          showStocks ? (
            <StockCard key={item.id} stock={item} onDelete={() => onDeleteStock(item.id)} className="w-full" />
          ) : (
            <CryptoCard key={item.id} crypto={item} onDelete={() => onDeleteCrypto(item.id)} className="w-full" />
          )
        ))}
      </div>
    </div>
  );
}

export default Dashboard;